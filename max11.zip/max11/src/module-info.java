/**
 * 
 */
/**
 * @author HP
 *
 */
module max11 {
	requires junit;
}