package max11;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test1 {

	@Test
	public void test() {
		findMax max = new findMax();
		int result = max.findMax1(new int[] {2,3,1,5});
		assertEquals(5, result);
		
	} 
	
	@Test
	public void test2() {
		findMax max1 = new findMax();
		int result = max1.findMax1(new int[] {});
		assertEquals(Integer.MIN_VALUE, result);
		
	}
	@Test
	public void test22() {
		findMax max1 = new findMax();
		int result = max1.findMax1(new int[] {4});
		assertEquals(4, result);
		
	}
	
	@Test
	public void test3() {
		findMax max1 = new findMax();
		int result = max1.findMax1(new int[] {-4,2,-1,-4,-7});
		assertEquals(2, result); 
		  
	}
	@Test
	public void test4() {
		findMax max1 = new findMax();
		int result = max1.findMax1(new int[] {-4, 2, -1});
		assertEquals(2, result);
		
	}
	
	@Test
	public void test5() {
		findMax max1 = new findMax();
		int result = max1.findMax2(new int[] {-4,-2,-1,-4,-7});
		assertEquals(-1, result);
		
	}
	
	
	@Test
	public void test9() {
		findMax max1 = new findMax();
		int result = max1.findMax2(new int[] {});
		assertEquals(Integer.MIN_VALUE, result);   
		
	}
	
  
}
