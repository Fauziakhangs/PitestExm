package max11;

public class findMax {
	// returns max number of an array

	public int findMax1(int arr[])
	{int max=0;
	if(arr.length==0) 
		return Integer.MIN_VALUE;
	for(int i=0;i<arr.length;i++)
	{ 
		if(max<arr[i])max=arr[i];
		}
	return max;  
	}
	
	
	public int findMax2(int arr[])
	{
		int max=arr.length;
	if(arr.length>0) {  
		max = arr[0]; 
	}
		max =  Integer.MIN_VALUE;
	for(int i=0 ; i<arr.length; i++)
	{if(max < arr[i]) 
		max = arr[i]; 
	
	}
	return max; 
	} 
	
	
	
} 
